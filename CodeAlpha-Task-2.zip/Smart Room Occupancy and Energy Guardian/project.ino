#include <LiquidCrystal.h>

// LCD pins: RS, E, D4, D5, D6, D7
LiquidCrystal lcd(12, 11, 5, 6, 7, 4);

// Component pins
const int pirEntry = 2;
const int pirExit = 3;
const int relayPin = 8;   // drives relay module IN directly (no transistor needed)
const int buzzerPin = 9;
const int ledPin = 10;

const int maxOccupancy = 1;  // change this to your desired limit

int occupancy = 0;
bool lastEntry = false;
bool lastExit = false;

void setup() {
  pinMode(pirEntry, INPUT);
  pinMode(pirExit, INPUT);
  pinMode(relayPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(ledPin, OUTPUT);

  digitalWrite(relayPin, LOW);

  lcd.begin(16, 2);
  lcd.print("Room Guardian");
  delay(1500);
  lcd.clear();
}

void loop() {
  bool entry = digitalRead(pirEntry);
  bool exitS = digitalRead(pirExit);

  if (entry && !lastEntry) {
    occupancy++;
    delay(300);
  }

  if (exitS && !lastExit && occupancy > 0) {
    occupancy--;
    delay(300);
  }

  lastEntry = entry;
  lastExit = exitS;

  // Relay controls the load LED (representing the room bulb)
  digitalWrite(relayPin, occupancy > 0 ? HIGH : LOW);

  // Overcrowding alert
  if (occupancy > maxOccupancy) {
    digitalWrite(ledPin, HIGH);
    tone(buzzerPin, 1000);
  } else {
    digitalWrite(ledPin, LOW);
    noTone(buzzerPin);
  }

  lcd.setCursor(0, 0);
  lcd.print("Occupancy: ");
  lcd.print(occupancy);
  lcd.print("   ");

  lcd.setCursor(0, 1);
  if (occupancy > maxOccupancy) {
    lcd.print("OVERCROWDED! ");
  } else {
    lcd.print("Status: OK    ");
  }

  delay(200);
}
